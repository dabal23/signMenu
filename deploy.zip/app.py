import streamlit as st

st.title('Application workflow')
st.sidebar.success('Select page :')
